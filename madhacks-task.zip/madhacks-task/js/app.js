function shuffleA(array) 
{   for (var i = array.length-1; i>0;i--)
   {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

//////////////

function clearT() //Function to clear Table by removing rows one by one
    {
      var tbody=document.getElementById('body');
      var rows=tbody.getElementsByTagName('tr');
      var rowNo=rows.length;
             
      for(var z=rowNo-1;z>-1;z--)
      {
          tbody.removeChild(rows[z]);
      }
    }
////////

window.onload = function()
{
    display();
};

////////

function display()
{   
    clearT();
    //create a <table> element and a <tbody> element
    var tb = document.getElementById("tab");
    var tbBody = document.getElementById("body");

for( var i=0;i<10;i++)
{
  var y = TABLE_DATA[i];
 var row = document.createElement("tr");
    for(var j = 0; j<4; j++)
        {    
           var Prop = ["id","name","thumbnailUrl","price"];
            var cell= document.createElement("td");
             cell.innerHTML = y[Prop[j]];
              row.appendChild(cell);
        }
        tbBody.appendChild(row);
         tb.appendChild(tbBody);
 }
}

/////////////

function shuffle()    // Function to execute the shuffle function and display it 
 {
    shuffleA(TABLE_DATA);
     display(TABLE_DATA);     
 }

 ////////////

 function compareprice(a,b)//Function to compare Price
    {
     return parseFloat(b.price)-parseFloat(a.price)
    
    }

 //////////////////////

function sortmain(array,comp) //This is the updated function for sorting which also sorts ID after sorting price
      
    {
      array.sort(comp);
      display();
    }


/////////////
